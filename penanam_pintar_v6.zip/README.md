Penanam Pintar v6 - Auto-upload (prepared)
-------------------------------------------
- Project created for you with the OAuth JSON included at android/app/client_secret.json
- To run:
  1. Install Flutter SDK and open this project in VS Code or Android Studio.
  2. Run `flutter pub get` to fetch dependencies.
  3. (Optional) If you want real TFLite inference, replace assets/model/multi_plant_health_v1.tflite with your trained model.
  4. Connect an Android device or use emulator and run `flutter run`.

Notes:
- The included client_secret.json is the OAuth credential you created; Android OAuth signing normally uses SHA-1 and package name.
- For Google Sign-In on Android, you may also need to configure OAuth consent screen and add SHA-1 from your debug keystore in Google Cloud Console (if you experience auth errors).
- I included a small stub AI analyzer; replace with real inference using tflite_flutter if you have a .tflite model.
